import base64
import hmac
import time
from urllib.parse import quote
import requests
import json


class OneNetClient:
    def __init__(self, user_id, access_key, product_id, device_name):
        self.user_id = user_id
        self.access_key = access_key
        self.product_id = product_id
        self.device_name = device_name
        self.token = self.get_token()

    def get_token(self):
        version = '2022-05-01'
        res = f'userid/{self.user_id}'
        et = str(int(time.time()) + 3600)
        method = 'sha1'

        # 自动补全Base64填充符
        access_key = self.access_key.ljust(len(self.access_key) + (4 - len(self.access_key) % 4) % 4, '=')
        try:
            key = base64.b64decode(access_key.encode('utf-8'))
        except Exception as e:
            print(f"access_key解码失败: {e}，请检查Key格式！")
            raise

        org = f"{et}\n{method}\n{res}\n{version}"
        sign_b = hmac.new(key=key, msg=org.encode(), digestmod=method)
        sign = base64.b64encode(sign_b.digest()).decode()
        sign = quote(sign, safe='')
        res = quote(res, safe='')
        token = f"version={version}&res={res}&et={et}&method={method}&sign={sign}"
        return token

    def get_platform_device_data(self):
        """从平台获取最新存储数据（有一定延迟，依赖设备上报频率）"""
        headers = {"authorization": self.token}
        url = f"https://iot-api.heclouds.com/thingmodel/query-device-property?product_id={self.product_id}&device_name={self.device_name}"

        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            result = response.json()

            print("\n=== 平台API响应详情 ===")
            print(f"状态码: {response.status_code}")
            print(f"响应内容: {json.dumps(result, ensure_ascii=False, indent=2)}")

            if result.get("code") == 0:
                raw_data = result.get("data")
                return self._parse_data(raw_data)
            else:
                print(f"平台数据获取失败: code={result.get('code')}, msg={result.get('msg')}")
                return None
        except Exception as e:
            print(f"平台数据请求异常: {e}")
            return None

    def get_device_real_time_data(self, attribute_list, timeout=5):
        """直接向设备实时请求数据（需设备在线并订阅Topic，实时性更高）"""
        url = "https://iot-api.heclouds.com/thingmodel/query-device-property-detail"
        headers = {"Content-Type": "application/json", "authorization": self.token}
        js_data = {
            "product_id": self.product_id,
            "device_name": self.device_name,
            "params": attribute_list
        }

        try:
            response = requests.post(url, headers=headers, json=js_data, timeout=timeout)
            response.raise_for_status()
            result = response.json()

            if result.get("msg") == "succ":
                return 0, result.get("data", {})
            else:
                return 1, f"设备响应失败: {result.get('msg')}"
        except requests.exceptions.Timeout:
            return 1, "请求超时（设备可能离线或响应慢）"
        except Exception as e:
            return 1, f"实时数据请求异常: {e}"

    def _parse_data(self, raw_data):
        """解析平台返回的列表结构（提取identifier和value）"""
        if not raw_data:
            return {}

        if isinstance(raw_data, list):
            parsed = {}
            for item in raw_data:
                identifier = item.get('identifier')
                value = item.get('value')
                if identifier and value:
                    parsed[identifier] = value
            return parsed
        elif isinstance(raw_data, dict):
            return raw_data
        else:
            print(f"未知数据结构: {type(raw_data)}, 原始数据: {raw_data}")
            return {}


# ---------------------- 持续运行入口 ----------------------
if __name__ == "__main__":
    # 替换为你的实际参数（从OneNET平台复制）
    USER_ID = "450229"
    ACCESS_KEY = "uibANbTg0gDAxfs/T1pEiUDdju5YvT4DqsEdPfM56Hek9WgC6t1dDFBdZtiF3qH4"
    PRODUCT_ID = "YETP61m8qr"
    DEVICE_NAME = "ET"

    client = OneNetClient(USER_ID, ACCESS_KEY, PRODUCT_ID, DEVICE_NAME)
    ATTRIBUTE_LIST = ["co2", "humi", "light", "noise", "temp", "tvoc"]  # 物模型属性列表

    print("=== 持续获取数据（按 Ctrl+C 退出） ===")
    try:
        while True:
            # ---- 选项1：从平台获取历史数据（依赖设备上报，有延迟） ----
            platform_data = client.get_platform_device_data()
            if platform_data:
                print("\n【平台实时数据】")
                print(f"二氧化碳 (co2): {platform_data.get('co2', '未获取到')}")
                print(f"湿度 (humi): {platform_data.get('humi', '未获取到')} %RH")
                print(f"光照 (light): {platform_data.get('light', '未获取到')}")
                print(f"噪声 (noise): {platform_data.get('noise', '未获取到')}")
                print(f"温度 (temp): {platform_data.get('temp', '未获取到')} °C")
                print(f"TVOC (tvoc): {platform_data.get('tvoc', '未获取到')}")

            # 间隔时间（单位：秒，根据需求调整，避免频繁请求触发限流）
            time.sleep(2)

    except KeyboardInterrupt:
        print("\n用户中断，程序退出。")