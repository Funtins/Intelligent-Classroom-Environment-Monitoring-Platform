import base64
import hmac
import time
from urllib.parse import quote
import requests
import json
from flask import Flask, jsonify, request
from flask_socketio import SocketIO, emit, Namespace
import threading
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SECRET_KEY'] = 'smart-campus-environment-secret'
socketio = SocketIO(app, cors_allowed_origins="*")


# 环境数据命名空间（解决broadcast兼容性问题）
class EnvironmentNamespace(Namespace):
    def on_connect(self):
        print('客户端连接')
        data = one_net_client.get_platform_device_data()
        if data:
            self.emit('environment_data', data)

    def on_disconnect(self):
        print('客户端断开连接')


# 注册命名空间
socketio.on_namespace(EnvironmentNamespace('/environment'))


# OneNET客户端类
class OneNetClient:
    def __init__(self, user_id, access_key, product_id, device_name):
        self.user_id = user_id
        self.access_key = access_key
        self.product_id = product_id
        self.device_name = device_name
        self.token = self.get_token()
        self.history_data = []
        self.lock = threading.Lock()

    def get_token(self):
        version = '2022-05-01'
        res = f'userid/{self.user_id}'
        et = str(int(time.time()) + 3600)
        method = 'sha1'

        access_key = self.access_key.ljust(len(self.access_key) + (4 - len(self.access_key) % 4) % 4, '=')
        try:
            key = base64.b64decode(access_key.encode('utf-8'))
        except Exception as e:
            print(f"access_key解码失败: {e}，请检查Key格式！")
            raise

        org = f"{et}\n{method}\n{res}\n{version}"
        sign_b = hmac.new(key=key, msg=org.encode(), digestmod=method)
        sign = base64.b64encode(sign_b.digest()).decode()
        sign = quote(sign, safe='')
        res = quote(res, safe='')
        token = f"version={version}&res={res}&et={et}&method={method}&sign={sign}"
        return token

    def get_platform_device_data(self):
        headers = {"authorization": self.token}
        url = f"https://iot-api.heclouds.com/thingmodel/query-device-property?product_id={self.product_id}&device_name={self.device_name}"

        try:
            # 增加超时时间，处理网络不稳定情况
            response = requests.get(url, headers=headers, timeout=15)  # 超时时间增加到15秒
            response.raise_for_status()
            result = response.json()

            if result.get("code") == 0:
                raw_data = result.get("data")
                return self._parse_data(raw_data)
            else:
                print(f"平台数据获取失败: code={result.get('code')}, msg={result.get('msg')}")
                return None
        except requests.exceptions.Timeout:
            print("OneNET API请求超时，正在重试...")
            return None
        except Exception as e:
            print(f"平台数据请求异常: {e}")
            return None

    def _parse_data(self, raw_data):
        if not raw_data:
            return {}

        if isinstance(raw_data, list):
            parsed = {}
            for item in raw_data:
                identifier = item.get('identifier')
                value = item.get('value')
                if identifier and value:
                    if identifier in ["co2", "humi", "temp", "tvoc", "noise"]:
                        parsed[identifier] = float(value)
                    else:
                        parsed[identifier] = value
            return parsed
        elif isinstance(raw_data, dict):
            return raw_data
        else:
            print(f"未知数据结构: {type(raw_data)}, 原始数据: {raw_data}")
            return {}

    def save_history(self, data):
        if not data:
            return

        with self.lock:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            history_item = {"timestamp": timestamp, **data}
            self.history_data.append(history_item)
            if len(self.history_data) > 100:
                self.history_data.pop(0)


# OneNET客户端实例（替换为你的参数）
one_net_client = OneNetClient(
    user_id="450229",
    access_key="uibANbTg0gDAxfs/T1pEiUDdju5YvT4DqsEdPfM56Hek9WgC6t1dDFBdZtiF3qH4",
    product_id="YETP61m8qr",
    device_name="ET"
)


# 后台线程：定期获取数据（优化版）
def fetch_data_periodically():
    while True:
        try:
            data = one_net_client.get_platform_device_data()
            if data:
                one_net_client.save_history(data)
                # 通过命名空间推送数据（自动广播，无需broadcast参数）
                socketio.emit('environment_data', data, namespace='/environment')
                print(f"推送数据: {data}")
            # 增加间隔时间，避免频繁请求
            time.sleep(10)  # 从5秒增加到10秒
        except Exception as e:
            print(f"获取数据异常: {e}")
            # 出错后延长重试时间
            time.sleep(20)


# API路由
@app.route('/api/current-data', methods=['GET'])
def get_current_data():
    data = one_net_client.get_platform_device_data()
    return jsonify(data or {})


@app.route('/api/history', methods=['GET'])
def get_history_data():
    start_time = request.args.get('start')
    end_time = request.args.get('end')

    history = one_net_client.history_data

    if start_time and end_time:
        filtered_history = []
        for item in history:
            item_time = datetime.strptime(item["timestamp"], "%Y-%m-%d %H:%M:%S")
            start = datetime.strptime(start_time, "%Y-%m-%dT%H:%M")
            end = datetime.strptime(end_time, "%Y-%m-%dT%H:%M")
            if start <= item_time <= end:
                filtered_history.append(item)
        history = filtered_history

    return jsonify(history)


# 启动后台数据获取线程
data_thread = threading.Thread(target=fetch_data_periodically)
data_thread.daemon = True
data_thread.start()

# 启动应用
if __name__ == '__main__':
    print("智慧校园环境监测系统启动中...")
    print("访问 http://localhost:5000 查看监测界面")
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)