import base64
import hmac
import time
from urllib.parse import quote
import requests
import json
import threading
from datetime import datetime
from flask import Flask, jsonify, request, render_template
from flask_socketio import SocketIO, emit, Namespace
import os
from openai import OpenAI
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('smart_classroom.log')
    ]
)
logger = logging.getLogger(__name__)

# 配置信息
API_KEY = "sk-37e92ea0c37d4a73a547572c2294271e"  # 你的API Key
BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"  # 百炼兼容模式地址

app = Flask(__name__)
app.config['SECRET_KEY'] = 'smart-campus-environment-secret'
socketio = SocketIO(app, cors_allowed_origins="*")

# 初始化OpenAI客户端（兼容百炼API）
client = OpenAI(
    api_key=API_KEY,
    base_url=BASE_URL
)

# 对话历史记录（支持多轮交互，最多保留20轮对话）
chat_history = [
    {"role": "system", "content": "你是智慧教室环境分析专家，能根据传感器数据给出教学环境优化建议，回答需简洁专业，使用项目符号。"}
]


# 环境数据命名空间（增加AI分析功能）
class EnvironmentNamespace(Namespace):
    def on_connect(self):
        logger.info('客户端连接')
        data = one_net_client.get_platform_device_data()
        if data:
            # 推送原始数据
            self.emit('environment_data', data)
            # 自动触发AI分析
            self.analyze_environment(data)

    def on_disconnect(self):
        logger.info('客户端断开连接')

    def analyze_environment(self, data):
        """调用DeepSeek-R1分析环境数据"""
        if not data:
            logger.warning("无环境数据，跳过AI分析")
            return

        # 构造分析Prompt（结合设备数据与评估标准）
        prompt = f"""
        分析智慧教室实时环境数据并生成教学建议：
        - 温度：{data.get('temp', 0)}℃，湿度：{data.get('humi', 0)}%
        - CO2：{data.get('co2', 0)}ppm，TVOC：{data.get('tvoc', 0)}ppb
        - 噪声：{data.get('noise', 0)}dB，光照：{data.get('light', 0)}lux

        请回答：
        1. 综合评估当前环境是否适合教学（需分点说明各指标状态）
        2. 若存在问题，给出具体设备调节建议（如空调、加湿器、通风设备）
        3. 从提升学习效率角度，补充1-2条环境优化策略
        要求：回答不超过300字，使用清晰的项目符号
        """

        # 调用模型（异步处理，不阻塞客户端）
        socketio.start_background_task(self._call_model, prompt)

    def _call_model(self, prompt):
        """异步调用DeepSeek-R1模型并返回结果"""
        try:
            # 添加到对话历史（控制历史长度，避免Token浪费）
            if len(chat_history) > 20:
                chat_history.pop(1)  # 保留system角色，移除最早的用户-助手对话
            chat_history.append({"role": "user", "content": prompt})

            # 发送模型请求
            completion = client.chat.completions.create(
                model="deepseek-r1",
                messages=chat_history,
                stream=True
            )

            # 处理流式响应
            analysis = ""
            for chunk in completion:
                if chunk.choices:
                    delta = chunk.choices[0].delta
                    if delta.content:
                        analysis += delta.content
                        # 实时推送流式响应（前端需支持）
                        self.emit('ai_analysis_stream', {"chunk": delta.content}, namespace='/environment')

            # 保存模型回复
            if analysis:
                chat_history.append({"role": "assistant", "content": analysis})
                # 推送给前端完整结果
                self.emit('ai_analysis', {"analysis": analysis})
                logger.info("AI分析完成，结果已推送")
        except Exception as e:
            error_msg = f"模型分析错误: {str(e)}"
            logger.error(error_msg)
            self.emit('ai_analysis', {"error": error_msg})


# 注册命名空间
socketio.on_namespace(EnvironmentNamespace('/environment'))


# OneNET客户端类
class OneNetClient:
    def __init__(self, user_id, access_key, product_id, device_name):
        self.user_id = user_id
        self.access_key = access_key
        self.product_id = product_id
        self.device_name = device_name
        self.token = self.get_token()
        self.history_data = []
        self.lock = threading.Lock()
        self.request_fail_count = 0  # 记录请求失败次数

    def get_token(self):
        version = '2022-05-01'
        res = f'userid/{self.user_id}'
        et = str(int(time.time()) + 3600)
        method = 'sha1'

        access_key = self.access_key.ljust(len(self.access_key) + (4 - len(self.access_key) % 4) % 4, '=')
        try:
            key = base64.b64decode(access_key.encode('utf-8'))
        except Exception as e:
            logger.error(f"access_key解码失败: {str(e)}，请检查Key格式！")
            raise

        org = f"{et}\n{method}\n{res}\n{version}"
        sign_b = hmac.new(key=key, msg=org.encode(), digestmod=method)
        sign = base64.b64encode(sign_b.digest()).decode()
        sign = quote(sign, safe='')
        res = quote(res, safe='')
        token = f"version={version}&res={res}&et={et}&method={method}&sign={sign}"
        return token

    def get_platform_device_data(self):
        headers = {"authorization": self.token}
        url = f"https://iot-api.heclouds.com/thingmodel/query-device-property?product_id={self.product_id}&device_name={self.device_name}"

        try:
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            result = response.json()

            if result.get("code") == 0:
                raw_data = result.get("data")
                self.request_fail_count = 0  # 重置失败计数
                return self._parse_data(raw_data)
            else:
                self.request_fail_count += 1
                logger.warning(f"平台数据获取失败: code={result.get('code')}, msg={result.get('msg')}, 失败次数: {self.request_fail_count}")
                return None
        except requests.exceptions.Timeout:
            self.request_fail_count += 1
            logger.warning(f"OneNET API请求超时，正在重试... 失败次数: {self.request_fail_count}")
            return None
        except Exception as e:
            self.request_fail_count += 1
            logger.error(f"平台数据请求异常: {str(e)}, 失败次数: {self.request_fail_count}")
            return None

    def _parse_data(self, raw_data):
        if not raw_data:
            return {}

        if isinstance(raw_data, list):
            parsed = {}
            for item in raw_data:
                identifier = item.get('identifier')
                value = item.get('value')
                if identifier and value:
                    if identifier in ["co2", "humi", "temp", "tvoc", "noise", "light"]:
                        parsed[identifier] = float(value)
                    else:
                        parsed[identifier] = value
            return parsed
        elif isinstance(raw_data, dict):
            return raw_data
        else:
            logger.warning(f"未知数据结构: {type(raw_data)}, 原始数据: {raw_data}")
            return {}

    def save_history(self, data):
        if not data:
            return

        with self.lock:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            history_item = {"timestamp": timestamp, **data}
            self.history_data.append(history_item)
            if len(self.history_data) > 100:
                self.history_data.pop(0)


# OneNET客户端实例
one_net_client = OneNetClient(
    user_id="450229",
    access_key="uibANbTg0gDAxfs/T1pEiUDdju5YvT4DqsEdPfM56Hek9WgC6t1dDFBdZtiF3qH4",
    product_id="YETP61m8qr",
    device_name="ET"
)


# 后台线程：定期获取数据
def fetch_data_periodically():
    while True:
        try:
            data = one_net_client.get_platform_device_data()
            if data:
                one_net_client.save_history(data)
                # 通过SocketIO推送数据（触发前端更新）
                socketio.emit('environment_data', data, namespace='/environment')
                logger.info(f"[数据更新] {data}")
            # 智能调整获取间隔：失败次数越多，间隔越长
            if one_net_client.request_fail_count > 5:
                time.sleep(30)  # 连续失败5次后，间隔30秒
            else:
                time.sleep(5)  # 正常间隔5秒
        except Exception as e:
            logger.error(f"获取数据异常: {str(e)}")
            time.sleep(20)  # 出错后延长间隔


# API路由（增强聊天接口）
@app.route('/')
def index():
    return render_template('index.html')  # 前端页面需包含聊天交互区域


@app.route('/api/current-data', methods=['GET'])
def get_current_data():
    data = one_net_client.get_platform_device_data()
    logger.info(f"API请求: /api/current-data, 数据: {data or {}}")
    return jsonify(data or {})


@app.route('/api/history', methods=['GET'])
def get_history_data():
    start_time = request.args.get('start')
    end_time = request.args.get('end')

    history = one_net_client.history_data
    logger.info(f"API请求: /api/history, 时间范围: {start_time} - {end_time}")

    if start_time and end_time:
        filtered_history = []
        for item in history:
            item_time = datetime.strptime(item["timestamp"], "%Y-%m-%d %H:%M:%S")
            start = datetime.strptime(start_time, "%Y-%m-%dT%H:%M")
            end = datetime.strptime(end_time, "%Y-%m-%dT%H:%M")
            if start <= item_time <= end:
                filtered_history.append(item)
        history = filtered_history

    return jsonify(history)


@app.route('/api/chat', methods=['POST'])
def chat_with_model():
    """处理用户主动提问的API（支持多轮对话，含详细错误处理）"""
    try:
        user_prompt = request.json.get("prompt", "").strip()
        if not user_prompt:
            logger.warning("API请求: /api/chat, 错误: 空提问")
            return jsonify({"error": "请输入有效问题"}), 400

        # 添加到对话历史（控制历史长度）
        if len(chat_history) > 20:
            chat_history.pop(1)  # 保留system角色，移除最早的对话
        chat_history.append({"role": "user", "content": user_prompt})
        logger.info(f"API请求: /api/chat, 提问: {user_prompt}")

        # 调用模型
        completion = client.chat.completions.create(
            model="deepseek-r1",
            messages=chat_history,
            stream=False  # 非流式接口，适合短对话
        )

        # 解析回复
        assistant_reply = completion.choices[0].message.content
        chat_history.append({"role": "assistant", "content": assistant_reply})
        logger.info(f"API响应: /api/chat, 回复长度: {len(assistant_reply)}字符")

        return jsonify({"reply": assistant_reply})

    except client.error.APIConnectionError as e:
        logger.error(f"模型连接错误: {str(e)}")
        return jsonify({"error": "模型服务连接失败，请稍后再试"}), 502
    except client.error.RateLimitError as e:
        logger.warning(f"模型请求频率限制: {str(e)}")
        return jsonify({"error": "请求过于频繁，请稍候再问"}), 429
    except client.error.APIError as e:
        logger.error(f"模型API错误: {str(e)}")
        return jsonify({"error": f"模型服务异常: {str(e)}"}), 500
    except Exception as e:
        logger.error(f"未知错误: {str(e)}")
        return jsonify({"error": f"处理失败: {str(e)}"}), 500


# 启动后台数据获取线程
data_thread = threading.Thread(target=fetch_data_periodically)
data_thread.daemon = True
data_thread.start()

# 启动应用
if __name__ == '__main__':
    logger.info("智慧教室环境分析系统启动中...")
    print("智慧教室环境分析系统启动中...")
    print("访问 http://localhost:5000 查看监测界面")
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)